import network
import utime
import ubinascii
import usocket
import machine

# Configure network credentials
ssid = 'ASUS_D0'
password = 'gamma_4355'

# Connect to the Wi-Fi network
wifi = network.WLAN(network.STA_IF)
wifi.active(True)
wifi.connect(ssid, password)

# Wait until the Wi-Fi connection is established
while not wifi.isconnected():
    utime.sleep(1)

# Print the network configuration details
print("Connected to Wi-Fi!")
print("Network Config:", wifi.ifconfig())
print("MAC Address:", ubinascii.hexlify(wifi.config("mac"), ":").decode())


